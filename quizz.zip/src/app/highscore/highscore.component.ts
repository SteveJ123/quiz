import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-highscore',
  templateUrl: './highscore.component.html',
  styleUrls: ['./highscore.component.css']
})
export class HighscoreComponent implements OnInit {
  scoreList: any;

  constructor(private http: HttpClient, private router: Router) { }

  ngOnInit(): void {
    this.http.get('http://localhost:3000/score').subscribe((result:any) =>{
      console.log(result);
      this.scoreList = result;      
  });
  }

  logout(){
    localStorage.removeItem("name");
    localStorage.removeItem("score");
    this.router.navigate([''])
  }

}
