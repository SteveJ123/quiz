import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userForm:any;
  userDoesNotExist: boolean = false;

  constructor(private formBuilder: FormBuilder, private http: HttpClient, private router: Router) { }

  ngOnInit(): void {
    this.userForm = this.formBuilder.group({      
      email: ["",Validators.required],
      password: ["",[Validators.required]]      
    });
  }

  login(e:any){
    console.log(this.userForm.value)
    this.http.get('http://localhost:3000/users').subscribe(result =>{
      console.log(result);
      let data:any = result;
      data.find((obj:any) => {
        if(obj.email === this.userForm.value.email && obj.password === this.userForm.value.password){
          console.log("true ")
          localStorage.setItem("name", obj.name);
          this.router.navigate(['quiz'])
        }else{
          this.userDoesNotExist = true;
        }
        
      })
    })

  }

}
