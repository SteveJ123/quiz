import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  userForm:any;
  userExist: boolean = false;

  constructor(private formBuilder: FormBuilder, private http: HttpClient) { }

  ngOnInit(): void {
    this.userForm = this.formBuilder.group({
      name: ["",[Validators.required]],
      email: ["",Validators.required],
      password: ["",[Validators.required]]      
    });
  }

  userAlreadyExist(){
    this.http.get('http://localhost:3000/users').subscribe(result =>{
      let data:any= result;
      this.userExist = false;
       let existTrue = data.find((obj:any) => {
        if(obj.name === this.userForm.value.name){
          // this.userAlreadyExist = true;
          this.userExist = true;
         
        }
      })

      if(!this.userExist){
        this.http.post('http://localhost:3000/users', this.userForm.value).subscribe(result => console.log(result));          
      }
    })
   
  }
  getUserDetail(e:any){
    console.log("user", this.userForm.value);
   this.userAlreadyExist(); 
   
     
    
    
  }



}
