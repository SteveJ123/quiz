import { HttpClient } from '@angular/common/http';
import { Component, ElementRef, ViewChild, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { iif } from 'rxjs';

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {
  questions: any;
  options: any;
  questionIndex = 0;
  correct: boolean = false;
  notCorrect: boolean = false;
  condition = "";
  score = 0;
  name: string | null = "";

  constructor(private formBuilder: FormBuilder, private http: HttpClient, private ElByClassName: ElementRef, private router: Router) { }

  ngOnInit(): void {
    this.name = localStorage.getItem("name");
    this.http.get('https://opentdb.com/api.php?amount=5&category=11&difficulty=easy&type=multiple').subscribe((result:any) =>{
      console.log(result.results); 
      this.questions = result.results;
      this.options = result.results;
      let count = 0;
      for (let x of this.options) {
       x.id = count;
       count = count +1;
        x.options = [x.correct_answer, ...x.incorrect_answers].sort();
        
      }
      console.log(this.options);
      this.questions = this.options;
        
      })
  }

  // onSelect(question: any, option: any) {
  //   if (question.QuestionTypeId == 1) {
  //     question.Options.forEach((x) => { if (x.Id != option.Id) x.Selected = false; });
  //   }

  IncrementQuestionIndex(){
    if(this.questionIndex <4){
      this.questionIndex += 1;
    }else{
      localStorage.setItem("score", this.score.toString())
      let obj = {
        name: this.name,
        score: localStorage.getItem("score")
      }
      this.http.post('http://localhost:3000/score', obj).subscribe(result => console.log(result));
      this.router.navigate(['highscore'])
    }
    
  }

  decrementQuestionIndex(){
    this.questionIndex -= 1;
  }

  getNextQuestion(correctOption:any){
    const btnElement = (<HTMLElement>this.ElByClassName.nativeElement).querySelectorAll(
      '.card'
      );
      // btnElement.innerHTML = 'This is Button';
      console.log(btnElement);
      for(let i=0; i<btnElement.length; i++){
        // console.log(btnElement[i].innerHTML.length, question.correct_answer.length);
        btnElement[i].classList.add('div-disable');
        if((btnElement[i].innerHTML).trim() == correctOption){
          btnElement[i].classList.add('correct');
          setTimeout(()=>{this.IncrementQuestionIndex()}, 2000);
        }
      }
  }

  answer(question:any, option:any, menuIcon: HTMLElement){
    console.log(question, option);
    this.correct = false;
    this.notCorrect = false;
    this.condition = "";

    if(option === question.correct_answer){
      console.log("correct")
      this.correct = true;
      this.condition = "correct"
      menuIcon.classList.add('correct');
      this.getNextQuestion(question.correct_answer)
      this.score += 10;
      setTimeout(()=>{this.IncrementQuestionIndex()}, 2000);
      // menuIcon.classList.remove('notCorrect');

    }else{
      console.log("not correct")
      this.notCorrect = true;
      this.condition = "notCorrect"
      menuIcon.classList.add('notCorrect');
      this.getNextQuestion(question.correct_answer);
      // menuIcon.classList.remove('correct');
     
    }
  }


  logout(){
    localStorage.removeItem("name");
    localStorage.removeItem("score");
    this.router.navigate([''])
  }
}
